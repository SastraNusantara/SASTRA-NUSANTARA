package id.mamangkoneksi.billing

import android.annotation.SuppressLint
import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null

    // Pemilih file (upload logo, import backup) untuk <input type="file"> di WebView
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            } else null
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    // Dialog "Simpan sebagai" untuk export .xls / .csv / .json (tanpa izin storage)
    private val saveExcel =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.ms-excel")) { writeTo(it) }
    private val saveJson =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { writeTo(it) }
    private val saveAny =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { writeTo(it) }

    private fun writeTo(uri: Uri?) {
        val bytes = pendingBytes
        pendingBytes = null
        if (uri == null || bytes == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "File berhasil disimpan", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            runOnUiThread {
                try {
                    pendingBytes = Base64.decode(base64, Base64.DEFAULT)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Data file tidak valid", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                when {
                    mime.contains("excel") -> saveExcel.launch(name)
                    mime.contains("json") -> saveJson.launch(name)
                    else -> saveAny.launch(name)
                }
            }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finishAndRemoveTask() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.databaseEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooserLauncher.launch(params!!.createIntent())
                    true
                } catch (e: Exception) {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back diatur oleh aplikasi: tutup menu/dialog -> kembali ke Dashboard -> layar terima kasih lalu keluar
                web.evaluateJavascript("(typeof handleBack==='function')?String(handleBack()):'false'") { r ->
                    if (r == null || !r.contains("true")) finish()
                }
            }
        })
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
