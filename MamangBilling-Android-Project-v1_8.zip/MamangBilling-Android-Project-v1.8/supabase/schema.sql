-- Jalankan di Supabase SQL Editor.
create table if not exists public.billing_snapshots (
  device_id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.billing_snapshots enable row level security;
-- DEMO: kebijakan ini sengaja TIDAK dibuat terbuka untuk publik.
-- Untuk produksi, buat autentikasi pengguna dan policy RLS berbasis auth.uid()
-- serta tambahkan owner_id uuid references auth.users(id) pada tabel.
-- Jangan pernah menaruh service_role key di aplikasi Android.
