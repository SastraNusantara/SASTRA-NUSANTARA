import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
const app=express();app.use(helmet());app.use(express.json({limit:'256kb'}));app.use(rateLimit({windowMs:60000,max:100}));
app.get('/health',(_req,res)=>res.json({ok:true,service:'billing-wifi-rwnet-api'}));
// TODO production: authentication, role-based authorization, persistent database,
// audit logs, input validation, TLS termination and MikroTik RouterOS v7 adapter.
// Never expose RouterOS credentials or its API port to the public internet.
app.use((_req,res)=>res.status(501).json({error:'Endpoint belum diimplementasikan'}));
const port=Number(process.env.PORT||3000);app.listen(port,'127.0.0.1',()=>console.log(`API listening on 127.0.0.1:${port}`));
