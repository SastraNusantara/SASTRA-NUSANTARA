# Billing WiFi RT/RWNet — Mamang Koneksi

Versi sumber aplikasi 1.1.0. Creator: **Mamang Koneksi (Tawab Hidayat)**.

## Fitur antarmuka yang tersedia
- Dashboard: total pelanggan, pendapatan bulan berjalan, tagihan belum dibayar, jatuh tempo, dan ringkasan tagihan.
- Pelanggan: tambah, edit, cari, filter Voucher/PPPoE, pilih paket, harga, dan tanggal jatuh tempo.
- Paket: tambah, edit, hapus paket, jenis layanan, harga, dan periode.
- Pembayaran/kasir: pilih pelanggan, jumlah, metode tunai/nontunai, catatan referensi, riwayat transaksi.
- Struk: detail transaksi dan cetak melalui dialog print Android/browser (dapat dipilih printer yang didukung perangkat).
- Pengaturan: nama usaha, admin, alamat backend HTTPS/VPN, backup/restore JSON.
- About: creator Mamang Koneksi (Tawab Hidayat).
- Penyimpanan lokal perangkat melalui localStorage.

## Build menjadi APK Android

Persyaratan: Node.js 20+, JDK 17, Android Studio, Android SDK (platform dan build-tools), serta koneksi internet saat mengunduh dependency pertama kali.

```bash
npm install
npm run build
npx cap add android       # jalankan sekali saja jika folder android belum ada
npx cap sync android
npx cap open android
```

Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug biasanya berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Status dan batasan penting

Ini adalah versi prototipe frontend yang dapat dikembangkan dan diuji sebagai aplikasi lokal. Data disimpan di perangkat, bukan database server. Belum ada login/otorisasi, multi-admin, sinkronisasi antardevice, penjadwalan invoice otomatis, notifikasi, payment gateway, atau provisioning RouterOS nyata. Fitur cetak menggunakan fasilitas print perangkat/browser dan memerlukan printer yang didukung.

Alamat backend di Pengaturan hanya menyimpan konfigurasi; endpoint backend produksi belum diimplementasikan. Integrasi MikroTik RouterOS v7 Hotspot Voucher/PPPoE harus dibuat di backend yang aman dan hanya dapat diakses melalui HTTPS/VPN. Jangan menyimpan password router di APK atau membuka API router ke internet publik.

**APK belum disertakan/dibangun dalam arsip ini.** Lingkungan pembuatan yang digunakan tidak memiliki Android SDK/Android Studio/Gradle, sehingga APK tidak dapat dikompilasi atau ditandatangani di sini. Jalankan langkah build di atas pada komputer yang memiliki Android Studio.

## Build APK otomatis melalui GitHub Actions

1. Buat repositori baru di GitHub, lalu unggah seluruh isi folder proyek ini (folder `.github` juga harus ikut terunggah) ke branch `main`.
2. Buka tab **Actions** pada repositori. Jika diminta, aktifkan GitHub Actions.
3. Pilih workflow **Build Android APK**, tekan **Run workflow**, lalu **Run workflow** sekali lagi.
4. Tunggu sampai proses berstatus hijau/berhasil.
5. Buka hasil run tersebut dan unduh file pada bagian **Artifacts** dengan nama `billing-wifi-mamang-koneksi-debug-apk`.
6. Ekstrak ZIP artifact dan pasang `app-debug.apk` pada perangkat Android. Jika Android meminta izin, izinkan pemasangan aplikasi dari sumber tersebut.

Workflow ini membuat **debug APK** untuk pengujian, bukan APK release yang ditandatangani untuk distribusi Play Store. Workflow membuat folder Android saat berjalan dengan `npx cap add android`, jadi folder `android/` tidak harus disimpan di repositori. Build tetap dapat gagal bila ada perubahan kode atau dependensi yang tidak kompatibel; periksa log run GitHub Actions jika itu terjadi.
