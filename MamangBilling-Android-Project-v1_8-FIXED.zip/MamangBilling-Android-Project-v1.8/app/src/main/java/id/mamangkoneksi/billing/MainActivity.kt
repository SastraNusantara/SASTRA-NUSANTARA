package id.mamangkoneksi.billing

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun startSave(name: String, mime: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = mime
        intent.putExtra(Intent.EXTRA_TITLE, name)
        startActivityForResult(intent, REQ_SAVE)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            runOnUiThread {
                try {
                    pendingBytes = Base64.decode(base64, Base64.DEFAULT)
                    startSave(name, mime)
                } catch (e: Exception) {
                    toast("Gagal menyiapkan file: " + e.message)
                }
            }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finish() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.databaseEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                if (params == null) {
                    return false
                }
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(typeof handleBack==='function')?String(handleBack()):'false'") { r ->
                    if (r == null || !r.contains("true")) {
                        finish()
                    }
                }
            }
        })
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val cb = filePathCallback
            filePathCallback = null
            if (cb != null) {
                if (resultCode == Activity.RESULT_OK) {
                    cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                } else {
                    cb.onReceiveValue(null)
                }
            }
        } else if (requestCode == REQ_SAVE) {
            val bytes = pendingBytes
            pendingBytes = null
            val uri = data?.data
            if (resultCode == Activity.RESULT_OK && uri != null && bytes != null) {
                try {
                    val out = contentResolver.openOutputStream(uri)
                    if (out != null) {
                        out.write(bytes)
                        out.close()
                    }
                    toast("File berhasil disimpan")
                } catch (e: Exception) {
                    toast("Gagal menyimpan file: " + e.message)
                }
            }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_FILE = 1001
        private const val REQ_SAVE = 1002
    }
}
