# Mamang Billing Android — v1.2.0

Aplikasi billing RT/RW Net oleh **Mamang Koneksi (Tawab Hidayat)**.

## Login awal
- Username: `admin`
- Password: `root@sastra`
- Jenis akun: Admin / Full Support

Segera ubah password setelah login pertama. Akun Kasir dapat dibuat dari Pengaturan > Manajemen akun.

## Fitur yang tersedia
- Dashboard: total pelanggan, pendapatan, pelanggan lunas/belum bayar, jatuh tempo, grafik pendapatan enam bulan.
- Pelanggan: tambah, edit, hapus; mode PPPoE atau Voucher.
- Pembayaran/kasir: tunai, transfer, QRIS, e-wallet, riwayat transaksi dan cetak struk.
- Paket: CRUD paket PPPoE/Voucher dan harga.
- Akun: Admin / Full Support dan User / Kasir.
- Tiket komplain: nomor tiket otomatis, data pelanggan, prioritas, status Baru/Diproses/Selesai, berbagi tiket melalui WhatsApp atau Telegram.
- Laporan: ekspor transaksi, pelanggan, tiket, atau seluruh laporan sebagai CSV UTF-8 yang dapat dibuka di Microsoft Excel/Google Sheets.
- WhatsApp Fonnte: konfigurasi token dan nomor tujuan serta tes kirim.
- Penyimpanan lokal offline, backup/restore JSON, dan konfigurasi snapshot Supabase satu arah.

## Build APK otomatis melalui GitHub Actions
Paket ini dilengkapi workflow `.github/workflows/build-apk.yml`.

1. Ekstrak ZIP ini.
2. Buat repository GitHub baru dan unggah seluruh isi folder `MamangBilling` (isi folder, bukan folder pembungkusnya) ke repository tersebut.
3. Buka tab **Actions** di repository GitHub.
4. Pilih workflow **Build Mamang Billing APK**, lalu tekan **Run workflow** (atau tunggu build otomatis setelah push ke branch `main`/`master`).
5. Setelah status workflow berhasil, buka hasil run dan unduh artifact **MamangBilling-debug-apk**.
6. Ekstrak artifact untuk memperoleh `app-debug.apk`, lalu pindahkan ke HP Android dan instal. Aktifkan izin instal aplikasi dari sumber yang Anda gunakan bila diminta Android.

Workflow memakai JDK 17, Gradle 8.9, dan Android SDK 35. APK debug cocok untuk pengujian/internal. Untuk distribusi resmi, buat APK release yang ditandatangani dengan keystore milik Anda.

## Catatan integrasi dan batasan versi
- Aplikasi menyimpan data secara lokal pada perangkat. Backend belum disediakan; sinkronisasi multi-perangkat belum aktif penuh.
- Tombol WhatsApp pada tiket memakai Fonnte jika token dan nomor tersedia; jika tidak, membuka tautan WhatsApp.
- Telegram saat ini membagikan detail tiket melalui Telegram Share. Pembuatan tiket langsung dari percakapan Telegram/WhatsApp memerlukan bot dan webhook di server; belum termasuk dalam APK ini.
- Sinkronisasi Supabase masih berupa snapshot satu arah, belum sinkronisasi multi-perangkat dua arah.
- Belum ada integrasi MikroTik/RouterOS/Radius atau suspend PPPoE otomatis.
- Ekspor Excel menggunakan CSV UTF-8 (Excel-compatible), bukan workbook XLSX dengan format lembar kerja.

## Keamanan penting sebelum produksi
Versi ini adalah prototipe awal. Akun dan data lokal disimpan di perangkat untuk demo, bukan sistem autentikasi aman. Untuk rilis produksi, pindahkan autentikasi ke backend, simpan password dengan hash kuat, gunakan HTTPS, role-based authorization di server, dan enkripsi data sensitif. Jangan gunakan password default pada produksi.

**Fonnte:** Token yang disimpan di aplikasi dapat diekstrak dari APK dan permintaan langsung dapat terkena pembatasan CORS/jaringan. Untuk produksi, buat backend/proxy yang menyimpan token Fonnte secara rahasia. Jangan menaruh token Fonnte atau Supabase service-role key di APK.
